'use strict'
const mensaje="mensaje para el usuario";

function mostrarMensajes() {
    console.log(mensaje);
    alert(mensaje);
}

