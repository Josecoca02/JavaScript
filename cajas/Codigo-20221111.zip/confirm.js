'use strict'

var acepta = confirm("¿Acepta las condiciones?");
console.log(acepta);
