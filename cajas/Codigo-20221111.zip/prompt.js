'use strict'

var mensaje = prompt("ingrese su mensaje");
console.log(mensaje);
